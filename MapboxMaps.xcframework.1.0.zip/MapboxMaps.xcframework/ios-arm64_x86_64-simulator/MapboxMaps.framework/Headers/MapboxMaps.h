#import <Foundation/Foundation.h>

//! Project version number for MapboxMaps.
FOUNDATION_EXPORT double MapboxMapsVersionNumber;

//! Project version string for MapboxMaps.
FOUNDATION_EXPORT const unsigned char MapboxMapsVersionString[];
